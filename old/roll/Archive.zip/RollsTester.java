public class RollsTester {
	public static void main ( String [] args )   {
           Rolls loop = new Rolls ( );
           loop.GetInfo ( );
           loop.RollTheDice ( );
           loop.ShowResults ( );
     }
	  }