public static void main ( String [] args ) {
       Electric bill = new Electric ( );
       bill.GetData ( );
       bill.CalculateCost ( );
       bill.PrintInfo ( );
}
