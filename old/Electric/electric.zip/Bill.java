import java.util.Scanner;
public class Bill {
	private char R, C, I;
	char residental = 'R', commercial = 'C', industrial = 'I';

public void GetData () {
	Scanner input = new Scanner (System.in);
	System.out.print ("asdfasdfasdf");
	info = new string;
    info = string.next();
    System.out.print ("How many hours have you used");
	elec = input.nextDouble ();
	if (info = I || C)
	System.out.print ("How many offpeak hours have you used");
	offpeak = input.nextDouble (); 
	}
public void CalculateCost (){
res = 12.00 + (elec * 0.095);

com = 12.00 ;
if (elec > 1000) 
com = com + (elec * 0.083);

induspeak = 152.00 ;
if (elec > 1000)
induspeak = induspeak + (elec * 0.109);

indusoff = 108.00;
if (offpeak > 1000)
indusoff = indusoff + (offpeak * 0.047);

}
public void PrintInfo () { 
	if (R)
	System.out.printf ("Residential Billing\n\n");
	System.out.printf ("Peak hours %f.2\n", elec);
	System.out.printf ("Total Cost %f.2\n", res);
	if (C)
    System.out.printf ("Commercial Billing\n\n");
	System.out.printf ("Peak hours %f.2\n", elec);
	System.out.printf ("Total Cost %f.2\n", com);
	if (I)
    System.out.printf ("Commercial Billing\n\n");
	System.out.printf ("Peak hours %f.2\n", elec);
    System.out.printf ("Offpeak hours %f.2\n", offpeak);
	System.out.printf ("Total Cost %f.2\n", induspeak + indusoff);	
}
}

	
	
	
	
	
	

	
	
