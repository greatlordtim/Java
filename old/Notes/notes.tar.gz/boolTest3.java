public class boolTest3 {
public static void main (String[] args) {
int i = 1, j = 2;
boolean b = (i > j);
if (b)
System.out.println("i + j");
else
System.out.println("i <= j");
}

}
