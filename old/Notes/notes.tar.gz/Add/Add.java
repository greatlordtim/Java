// Jimmy Liu
// October 17, 2012
// LoopExample.java
// An example of counting from 1 to 10 using while and do-while loops

import java.util.Scanner;
public class Add {
	private int row;    // The number of rows for the addition table.
	private int column; // The number of columns for the addition table.
	Scanner input = new Scanner ( System.in );
	
	// Initializes the values of the above data members.
	public Add (){


	// Prompt the user to enter the number of rows in their addition table.
	// This value should be chosen from 2 to 30, and if the user enters a value
	// outside of this range, they should be prompted again.
	public void GetRows ( )


   public static void main (String[] args) {
