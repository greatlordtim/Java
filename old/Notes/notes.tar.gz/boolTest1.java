public class boolTest1 {
    public static void main (String[] args) {
        int i = 1, j = 2;
        if (i > j)
        System.out.println("i > j");
     else 
        System.out.println("i <= j");
     }
}
