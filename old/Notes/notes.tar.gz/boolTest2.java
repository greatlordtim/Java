public class boolTest2 {
  public static void main (String[] args) {
  int i = 1, j =2;
  boolean b = (i > j);
  System.out.println("b = " + b);
  }
